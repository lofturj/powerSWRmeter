Cut/Paste from the LUFA USB to Serial bridge project:
(See http://www.fourwalledcubicle.com)

 *  USB to Serial bridge project. This project allows a USB AVR to serve
 *  as a USB to USART bridge between a USB host and a device lacking a
 *  USB port. When programmed into a USB AVR, the AVR will enumerate as a
 *  virtual COM port.
 *
 *  The AVR's hardware USART's settings will change to mirror as closely as
 *  possible the serial settings set on the host. However, due to hardware
 *  limitations, some options may not be supported (baud rates with unacceptable
 *  error rates at the AVR's clock speed, data lengths other than 6, 7 or 8 bits,
 *  1.5 stop bits, parity other than none, even or odd).
 *
 *  After running this project for the first time on a new computer,
 *  you will need to supply the .INF file located in this project
 *  project's directory as the device's driver when running under
 *  Windows. This will enable Windows to use its inbuilt CDC drivers,
 *  negating the need for custom drivers for the device. Other
 *  Operating Systems should automatically use their own inbuilt
 *  CDC-ACM drivers.

Note that Windows may complain about an unsigned driver.  
This is OK, even for Windows 7 64-bit version, as the actual
driver being pointed at is a native Windows driver.
It is just the .INF file that is unsigned.
